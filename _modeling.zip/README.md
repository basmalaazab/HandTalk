---
title: ASL Fingerspelling Live Demo
emoji: 🤟
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 4.44.1
app_file: app.py
pinned: false
license: mit
---

# ASL Fingerspelling Recognition — Live Camera Demo

Live demo for [basmalaazab/asl-fingerspelling-transformer](https://huggingface.co/basmalaazab/asl-fingerspelling-transformer).

Turns on your webcam, extracts hand + pose landmarks with MediaPipe in
real time, buffers a short window of motion, and runs the Transformer
model to predict the fingerspelled phrase.

## How to use

1. Allow camera access when the browser asks.
2. Spell a word clearly with your dominant hand in view of the camera.
3. Every ~60 frames the app reads the buffered motion and shows a
   prediction in the text box.

## Notes

- Works best with good lighting and the hand clearly visible.
- If `character_to_prediction_index.json` isn't present in this Space's
  files, predictions show as raw token ids instead of letters — upload
  that file (from your training data) to the Files tab to get readable
  text.
- Model weights and architecture are pulled automatically from the
  [model repo](https://huggingface.co/basmalaazab/asl-fingerspelling-transformer)
  at startup.
