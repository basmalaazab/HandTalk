"""
upload_space.py
----------------
Uploads this folder as a Hugging Face Space (Gradio app).

Setup (once, same as before):
    pip install huggingface_hub
    python -c "from huggingface_hub import login; login()"

Then:
    python upload_space.py --repo-id your-username/asl-fingerspelling-live
"""

import argparse

from huggingface_hub import HfApi, create_repo

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-id", required=True, help="e.g. your-username/asl-fingerspelling-live")
    parser.add_argument("--private", action="store_true")
    parser.add_argument("--folder", default=".")
    args = parser.parse_args()

    create_repo(
        args.repo_id,
        repo_type="space",
        space_sdk="gradio",
        private=args.private,
        exist_ok=True,
    )

    api = HfApi()
    api.upload_folder(
        folder_path=args.folder,
        repo_id=args.repo_id,
        repo_type="space",
        ignore_patterns=["*.ipynb_checkpoints*", "__pycache__/*"],
    )

    print(f"Done. View it at: https://huggingface.co/spaces/{args.repo_id}")
